function OpenWin(win_name,win_url,win_pageparam) {
    api.openWin({
        name: win_name,
        url: win_url,
        pageParam:win_pageparam,
        vScrollBarEnabled:false,
        hScrollBarEnabled:false,
        animation:{
            type:"push",
            subType:"from_right",
            duration:300
        },
        softInputBarEnabled:false
    });
}
function CloseWin() {
    api.closeWin({
        animation:{
            type:"push",
            subType:"from_left",
            duration:300
        },
    });
}
function CloseToWin(win_name) {
    api.closeToWin({
        name: name,
        animation:{
            type:"push",
            subType:"from_left",
            duration:300
        },
    });
}