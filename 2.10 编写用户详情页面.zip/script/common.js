function OpenWin(win_name, win_url, win_pageparam) {
    api.openWin({
        name: win_name,
        url: win_url,
        pageParam: win_pageparam,
        vScrollBarEnabled: false,
        hScrollBarEnabled: false,
        animation: {
            type: "fade",
            duration: 300
        },
        softInputBarEnabled: false
    });
}
function CloseWin() {
    api.closeWin({
        animation: {
            type: "fade",
            duration: 300
        },
    });
}
function CloseToWin(win_name) {
    api.closeToWin({
        name: win_name,
        animation: {
            type: "fade",
            duration: 300
        }
    });
}
function OpenLoadingMiddle() {
    var activity = api.require('UILoading');
    var content=[];
    for(var i=0;i<50;i++){
        content.push({frame: 'widget://image/middle_loading/'+i+'.png'})
    }
    activity.keyFrame({
        rect: {
            w: 34,
            h: 34
        },
        styles: {
            bg: 'rgba(0,0,0,0)',
            corner: 5,
            interval: 40,
            frame: {
                w: 34,
                h: 34
            }
        },
        content:content
    });

}
function CloseLoadingMiddle() {
    var uiloading = api.require('UILoading');
    uiloading.closeKeyFrame();
}

function TplInnerHtmlLoad(tpl_id, show_id, data) {
    var tplhtml = doT.template($api.byId(tpl_id).innerHTML);
    $api.byId(show_id).innerHTML = tplhtml(data);
    api.parseTapmode();
}

function TplAppendLoad(tpl_id, show_id, data) {
    var tplhtml = doT.template($api.byId(tpl_id).innerHTML);
    $api.append($api.byId(show_id), tplhtml(data))
    api.parseTapmode();
}

function OpenLoading(append_id) {
    var html="";
    html+="<div id='loading' style='background: #ffffff;text-align: center;padding: 4px 0;'>";
    html+="<img src='";
    html+=api.wgtRootDir;
    html+="/image/defult/loading.gif' style='height: 30px'>";
    html+="</div>";
    $api.append($api.byId(append_id),html)
}
function CloseLoading() {
    $api.remove($api.byId('loading'));
}

function SetTopLoading(callback) {
    api.setCustomRefreshHeaderInfo({
        bgColor: '#ffffff',
    }, function() {
        (callback && typeof(callback) === "function") && callback();
    })
}

function OpenTopLoading() {
    api.refreshHeaderLoading();
}

function CloseTopLoading() {
    api.refreshHeaderLoadDone()

}

